import React, { useState } from "react";
import { FaTimes } from "react-icons/fa";
import { GiHamburgerMenu } from "react-icons/gi";
import { Link } from "react-router-dom";
import "../../App.css";
function Navbars() {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(true);

  return (
    <div className="flex justify-center bg-[#0C8195]">
      <div className="navbar flex justify-between items-center h-[106px] w-[70%] text-white">
        <h4 className="text-[32px] font-normal md:-ml-20">
          <Link
            className="flex gap-2 items-center sm:flex  hover:text-[#F1C111]"
            to={"/"}
          >
            <i class="fa fa-line-chart"></i>Ditigel Trend
          </Link>
        </h4>
        <div className="lg:hidden flex ">
          <div
            className="duration-300 transition-all md:ml-[530px] md:pl-0 lg:pl-0 xl:pl-0"
            onClick={() => {
              setOpen(!open);
              setMenu(!menu);
            }}
          >
            {menu ? (
              <button>
                <GiHamburgerMenu color="#fff" fontSize={"30px"} />
              </button>
            ) : (
              <button
                onClick={() => {
                  setMenu(false);
                }}
              >
                <FaTimes color="#fff" fontSize={"30px"} />
              </button>
            )}
          </div>
        </div>

        <div className="mt-[-40px] flex justify-center">
          <div
            className={`w-full flex justify-center m-0 ${
              open ? "h-[240px] w-full p-0 m-0 flex justify-center" : "h-0"
            } overflow-hidden bg-[#0C8195] overflow-x-hidden justify-items-center top-0 mt-[100px] w-full left-0 z-50 absolute duration-300 transition-all flex flex-col items-start  gap-5 `}
          >
            <div className="grid justify-items-center w-full text-center items-center gap-5">
              <Link
                className="font-semibold mt-1 text-[13px] uppercase hover:text-[#F1C111] cursor-pointer ml-[15px]"
                activeClass="active"
                spy
                to="/"
              >
                Studio
              </Link>
              <Link
                className="font-semibold mt-1 text-[13px] uppercase  hover:text-[#F1C111] cursor-pointer ml-[15px]"
                activeClass="active"
                spy
                to="#Carousels"
              >
                Our works
              </Link>
              <Link
                className="font-semibold mt-1 text-[13px] uppercase hover:text-[#F1C111] cursor-pointer  ml-[15px]"
                activeClass="active"
                spy
                to="port"
              >
                Blogs
              </Link>
              {/* <Link
              className="font-semibold mt-1 text-[13px] uppercase  hover:text-[#F1C111] cursor-pointer ml-[15px]"
              activeClass="active"
              spy
              to="res"
              >
              <button
              style={{ border: "2px solid #F1C111" }}
              className="w-[116.98px] h-[43.8px] text-[#F1C111] rounded-full text-base"
              >
              Contact
              </button>
            </Link> */}
              <button
                style={{ border: "2px solid #F1C111" }}
                className="w-[116.98px] h-[43.8px] text-[#F1C111] rounded-full text-base"
              >
                <Link to={"/contact"}>Contact</Link>
              </button>
            </div>
          </div>
        </div>

        <div className=" items-center gap-10 hidden lg:flex">
          <a className="hover:text-[#F1C111] cursor-pointer">Studio</a>
          <a href="#Carousels" className="hover:text-[#F1C111] cursor-pointer">
            Our works
          </a>
          <Link to={"/blog"} className="hover:text-[#F1C111]">
            Blog
          </Link>
          <button
            style={{ border: "2px solid #F1C111" }}
            className="w-[116.98px] h-[43.8px] text-[#F1C111] rounded-full text-base hover:bg-[#F1C111] hover:text-white font-bold"
          >
            <Link to={"/contact"}>Contact</Link>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Navbars;
